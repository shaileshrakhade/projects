<html>
<head>
	
	<meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Page Not Found</title>
    <meta name="description" content="">
    <meta name="keywords" content=""/>
    <link rel="shortcut icon" href="/images/shortcut-icon.png">
		<meta name="theme-color" content="#000000">
    <link rel="manifest" href="/manifest.json">

		<link rel="apple-touch-icon" href="/appicons/icons-512.png">
		<link rel="apple-touch-icon" sizes="76x76" href="/appicons/icons-76.png">
		<link rel="apple-touch-icon" sizes="120x120" href="/appicons/icons-120.png">
		<link rel="apple-touch-icon" sizes="152x152" href="/appicons/icons-152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="/appicons/icons-180.png">
		<link rel="apple-touch-icon" sizes="167x167" href="/appicons/icons-167.png">
	<link rel="stylesheet" href="/css/style.min.css"/>
	<link rel="stylesheet" href="/css/header.min.css"/>
		<link rel="stylesheet" href="/css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="/css/owl.theme.default.min.css"/>
	<style>
	.august-comobo-sale .desktop-banner {
		display: block;
	}
	.august-comobo-sale .mobile-banner {
		display: none;
	}

	.offer-badge {
		position: absolute;
		right: 30px;
		top: 30px;
	}
	.product-offer-badge img{
		width: 60px;
		height: auto;
	}
	/* .productpage.offer-badge{
		position: relative;
	} */
	.offer-badge img {
		width: 60px;
		height: auto;
	}
	.thunder-ads img {
		display: none;
		width:100%;
	}
	.thunder-ads img.thunder-ads-desktop {
		display: block;
	}
	@media (max-width:767px) {
		.august-comobo-sale .mobile-banner {
			display: block;
		}
		.august-comobo-sale .desktop-banner {
			display: none;
		}

		.offer-badge {
			width: 24% !important;
		}
		.offer-badge img {
			/* height: 62px !important;			 */
		}
		.thunder-ads img.thunder-ads-mobile {
			display: block;
		}
		.thunder-ads img.thunder-ads-desktop {
			display: none;
		}
	}
</style>
	<script>
		var isLoginUser = false;
			</script>
	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-MSP2XGK');</script>
	<!-- End Google Tag Manager -->

	
	
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-68285818-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-68285818-1');
  gtag('config', 'AW-976383652');
</script>

<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1123583460985649');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1123583460985649&ev=PageView&noscript=1"
/></noscript>


<script type='text/javascript'>
  (function(win, doc, sdk_url){
  if(win.snaptr) return;
  var tr=win.snaptr=function(){
  tr.handleRequest? tr.handleRequest.apply(tr, arguments):tr.queue.push(arguments);
};
  tr.queue = [];
  var s='script';
  var new_script_section=doc.createElement(s);
  new_script_section.async=!0;
  new_script_section.src=sdk_url;
  var insert_pos=doc.getElementsByTagName(s)[0];
  insert_pos.parentNode.insertBefore(new_script_section, insert_pos);
})(window, document, 'https://sc-static.net/scevent.min.js');

  snaptr('init','a493a0f8-059c-41e7-9217-c44fc6f0d56e',{
  'user_email':''
})
  snaptr('track','PAGE_VIEW');
</script>
<!--


<script type="text/javascript" src="//event.getblue.io/js/blue-tag.min.js" async="true"></script>
<script type="text/javascript">
window.blue_q = window.blue_q || [];
window.blue_q.push(
	{event: "setCampaignId", value: "6D4D3AE5-0585-EDFA-876BC2489CDD547A"}
	,{event: "setPageType", value: "visit"}
);
</script>
-->
<!--Start of Zendesk Chat Script-->


<script>
	function getBeardoCookie(cname) {
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for(var i = 0; i < ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0) == ' ') {
	            c = c.substring(1);
	        }
	        if (c.indexOf(name) == 0) {
	            return c.substring(name.length, c.length);
	        }
	    }
	    return "";
	}
</script>

<script type="application/ld+json">
{
 "@context": "http://schema.org",
 "@type": "Organization",
 "name": "Beardo.in",
 "url": "https://www.beardo.in/",
 "logo": "https://www.beardo.in/images/corporatebeardologo.png",
 "contactPoint": [{
   "@type": "ContactPoint",
   "telephone": "+91-7818000555",
   "contactType": "customer service",
     "areaServed" : "IN"
 }],
	"sameAs":[
	"https://www.facebook.com/beardoofficial/",
	"https://www.instagram.com/beardo.official/?hl=en",
	"https://www.twitter.com/beardoformen?lang=en",
	"https://www.youtube.com/channel/UC8tE3gNWC-B6BqLuKkqivxw"
	]
}
</script>

<script>
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
  // Prevent Chrome 67 and earlier from automatically showing the prompt
  e.preventDefault();
  // Stash the event so it can be triggered later.
  deferredPrompt = e;
	setTimeout(()=> {
		promptUserToInstallApp();
	}, 1000);
});
function promptUserToInstallApp(){
	if (window.matchMedia("(max-width: 800px)").matches) {
		deferredPrompt.prompt();
  // Wait for the user to respond to the prompt
		deferredPrompt.userChoice
			.then((choiceResult) => {
				if (choiceResult.outcome === 'accepted') {
					gtag('event', 'Installed On Home Screen', {
						'event_category': 'HomeScreen',
						'event_label': 'accepted'
					});

					console.log('User accepted the A2HS prompt');
				} else {
					gtag('event', 'Not Installed On Home Screen', {
						'event_category': 'HomeScreen',
						'event_label': 'rejected'
					});
					console.log('User dismissed the A2HS prompt');
				}
				deferredPrompt = null;
			});
	}
}

if ('serviceWorker' in navigator) {
	console.log("Will the service worker register?");
	navigator.serviceWorker.register('/service-worker.js')
		.then(function(reg){
			console.log("Yes, it did.");
		}).catch(function(err) {
			console.log("No it didn't. This happened: ", err)
		});
}
</script>
<meta name="google-signin-client_id" content="772072312180-gmkenh6sr1hdace6i9lcq0q9897cuoru.apps.googleusercontent.com"></head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MSP2XGK"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<header>
	
	<div class="header-top">
		<div class="container">
			<div class="left">
				<a href="/">
					<img src="/images/logo-white.png" class="logo" alt="Beardo.in">
				</a>
			</div>
			<nav class="menu">
                <ul>
                    <li class="has-sub-menu">
                    	<a href="/categories" onclick="openMobileSubMenu(this); return false;">Products</a>
                        <ul class="sub-menu">
                            							<li>
								<a href="/categories/beard">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-growthoil-181.jpg">
									<p>Beard</p>
								</a>
							</li>
														<li>
								<a href="/categories/fragrance">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-1-1792.jpg">
									<p>Fragrance</p>
								</a>
							</li>
														<li>
								<a href="/categories/turmeric-range">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-turmeric-face-scrub-512x512-2680.png">
									<p>Turmeric Range</p>
								</a>
							</li>
														<li>
								<a href="/categories/hair">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-hair-29.png">
									<p>Hair</p>
								</a>
							</li>
														<li>
								<a href="/categories/skin">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-skin-30.png">
									<p>Skin</p>
								</a>
							</li>
														<li>
								<a href="/categories/combo">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-combo-32.png">
									<p>Combo</p>
								</a>
							</li>
														<li>
								<a href="/categories/gift">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-tshirt-new-1844.jpg">
									<p>Gift</p>
								</a>
							</li>
														<li>
								<a href="/categories/tools">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-tools-34.png">
									<p>Tools</p>
								</a>
							</li>
							                        </ul>
                    </li>
                    <li class="has-sub-menu"><a href="#" onclick="openMobileSubMenu(this); return false;">Concerns</a>
						<ul class="sub-menu">
                            							<li>
								<a href="/concerns/hair-fall">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-hfc-600x600-81.jpg">
									<p>Hair Fall</p>
								</a>
							</li>
														<li>
								<a href="/concerns/acne">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-new-ultraglow-copy-600x600-82.jpg">
									<p>Acne</p>
								</a>
							</li>
														<li>
								<a href="/concerns/beard-growth">
									<img class="lazy" data-src="//beardoc.s3.ap-south-1.amazonaws.com/uploads/x100-growthoil-185.jpg">
									<p>Beard Growth</p>
								</a>
							</li>
							                        </ul>
                    </li>
                    <li><a href="/community">Community</a></li>
                    <li class="has-sub-menu"><a href="#" onclick="openMobileSubMenu(this); return false;">About</a>
						<ul class="sub-menu">
                            <li><a href="/about-us">WHO WE ARE</a></li>
                            <li><a href="/careers">CAREERS</a></li>
                            <li><a href="/privacy-policy">PRIVACY POLICY</a></li>
							<li><a href="/terms-conditions">TERMS &amp; CONDITIONS</a></li>
							<li><a href="/beardo-points-rewards">POINTS &amp; REWARDS</a></li>
							<li><a href="/return-refund-policy">RETURN POLICY</a></li>
							<li><a href="/contact-us">CONTACT US</a></li>
							<li><a href="/blog">BLOG</a></li>
							<li><a href="/community">COMMUNITY</a></li>
							<li><a href="/account/wishlist">WISHLIST</a></li>
						</ul>
                    </li>
                </ul>
            </nav>
			<div class="right">
				<div class="menu-icon">
					<a href="javascript:void(0);" class="search-btn"><img src="/images/home-2018-05-search.png"></a>
					<a href="/login" class="account"><img src="/images/home-2018-05-user.png"><p>Account</p></a>
					<a href="/cart" class="cart"><img src="/images/home-2018-05-cart.png"><p>Cart</p></a>	
				</div>
				
				<div class="mobile-menu-icon">
					<span></span>
					<span></span>
				</div>
				
			</div>
		</div>
		<div class="search-container">
			<nav style="position: relative;">
				<ul>
					<li class="search active" id="headerSearchli">
						<form  onsubmit="window.location = '/search/' + encodeURIComponent($('#headerSearch').val()); return false;">
							<input type="text" name="search" id="headerSearch" autocomplete="off" autocorrect="off" value="" autocapitalize="off" spellcheck="false" placeholder="Search"/>
						</form>
					</li>
				</ul>
				<div class="search-result">
					<ul id="headersearchresults">
					</ul>
				</div>
			</nav>
		</div>
	</div>
		<div class="thunder-ads">
		<a href="/"><img src="https://beardoc.s3.ap-south-1.amazonaws.com/paypal/paypal-desktop.jpg" class="thunder-ads-desktop"></a>
		<a href="/"><img src="https://beardoc.s3.ap-south-1.amazonaws.com/paypal/paypal-mobile.jpg" class="thunder-ads-mobile"></a>
	</div>
</header>
	<section>
		<div class="container">					
			<div class="page-not-found">
				<label>
					opps! Could not found it.
				</label>
				<p>
					404
				</p>
			</div>
		</section>
		<section class="signup-rewd">
	<!-- <div class="container">
		<h1> <a href="/login" style="color: red;">Sign up</a> to get 500 reward points and use it from your first purchase</h1>
		<p> * Get Reward points every purchase and use it in your next purchase</p>
	</div> -->
</section>	
<footer class="footervisible">
	<div class="container">
		<div class="footer">
			<div class="first-col">
				<h1>products</h1>
				<ul>
					<div class="firstdiv">
													<a href="/categories/beard"><li>Beard </li></a>
														<a href="/categories/fragrance"><li>Fragrance </li></a>
														<a href="/categories/turmeric-range"><li>Turmeric Range </li></a>
														<a href="/categories/hair"><li>Hair </li></a>
														<a href="/categories/skin"><li>Skin </li></a>
														</div>
							<div class="secdiv">
														<a href="/categories/combo"><li>Combo </li></a>
														<a href="/categories/gift"><li>Gift </li></a>
														<a href="/categories/tools"><li>Tools </li></a>
													</div>	
						<div class="thirddiv">
							<a href="/about-us"><li> Who we are </li></a>
							<a href="/community"><li>Community </li></a>
							<a href="/blog"><li>Blog </li></a>
							<a href="/beardothon"><li>Beardothon</li></a>
							<!-- <a href="/contact-us"><li>Contact us</li></a> -->
						</div>	
						<div class="fourthdiv">
							<a href="/careers"><li> Careers</li></a>
						</div>	

					</ul>

				</div>
				<div class="sec-col">
					<h1>order</h1>
					<ul>

						<div>
							<a href="/account/"><li>Account </li></a>
							<a href="/cart"><li>Cart </li></a>
							<a href="/account/wishlist"><li>Wishlist </li></a>
							<a href="/track-order"><li>Track Order </li></a>
						</div>	
						<div>
							<a href="/faqs"><li>FAQ's</li></a>
							<a href="/terms-conditions"><li>Terms & Conditions</li></a>
							<a href="/privacy-policy"><li> Privacy Policy </li></a>
							<a href="/return-refund-policy"><li>Return & Refund Policy </li></a>
							<a href="/paypal-offers"><li>PayPal Terms </li></a>
																					<!-- <a href="/spin2win-terms"><li>Spin 2 Win Terms </li></a> -->
						</div>	
					</ul>
				</div>
				<div class="third-col">
					<h1>community</h1>
					<div class="socialimg">
						<a href="https://www.facebook.com/beardoofficial/" target="_blank"><img src="/images/fb.png"></a>
						<a href="https://www.instagram.com/beardo.official/?hl=en" target="_blank"><img src="/images/instag.png"></a>	
						<a href="https://twitter.com/beardoformen?lang=en" target="_blank"><img src="/images/twitter.png"></a>
						<a href="https://www.youtube.com/channel/UC8tE3gNWC-B6BqLuKkqivxw" target="_blank"><img src="/images/youtube.png"></a>
					</div>
					<div class="social-cont">
						<p> SIGN UP FOR EMAIL </p>
						<h5>Deals, News and Stealth products releases. </h5>
						<p id="fnewsformloading" style="display: none;">signing up..</p>
						<form name="fnewsform" id="fnewsform" onsubmit="return submitFNewsForm();">			
							<input placeholder="Email" type="text" id="fnewsformemail">
							<input value="Sign Up" type="submit" class="signup">
						</form>
					</div>
				</div>
			</div>			
		</div>	
	</footer>
	<div class="copyright-div">
		<div class="container">
			<div class="copyright">
				<h2>copyright 2019 </h2>
				<h1>zed lifestyle pvt. ltd.  </h1>
				<h2>all rights reserved</h2>
			</div>
		</div>	
	</div>

		<div class="home-popup" style="display: none;">
		<div class="pop-header">
			<h3>Beardo Points & Rewards</h3>
			<a href="#" onclick="closePopup(); return false;" class="pop-close">
				<span></span>
				<span></span>
			</a>
		</div>
		<div class="pop-content">
			<p>Get Reward points on every purchase and use it in your next purchase. <br><a href="/beardo-points-rewards"><span class="hide">Click Here to</span><span> k</span>now more</a></p>
		</div>
	</div>
<script>
	function showSimplePopup(){
		if (!shouldNotShowAgain()) {
			document.querySelector('.simple-popup').classList.add('show');
		}
	}
	function closeSimplePopup(){
		document.querySelector('.simple-popup').classList.remove('show');
		stopShowAgain();
	}
	function clickedOnSimplePopup(){
		document.querySelector('.simple-popup').classList.remove('show');
		stopShowAgain();
	}
	function stopShowAgain(){
		localStorage.setItem("webpopup", "Y");
	}
	function shouldNotShowAgain(){
		let n = localStorage.getItem("webpopup");
		if(n == null){
			return false;
		} else if(n == "Y"){
			return true;
		}
	}
		
</script>

<style>
.ios-addtohome {
	display: none;
    position: fixed;
    bottom: 0px;
    left: 0px;
    width: 100%;
    justify-content: center;
    align-items: center;
}
.ios-addtohome.show {
	display: flex;
}

.ios-addtohome-content {
    position: relative;
}

.ios-addtohome-close {
    position: absolute;
    top: -7px;
    right: -7px;
}
</style>
<div class="ios-addtohome">
	<div class="ios-addtohome-content">
		<div class="ios-addtohome-close"><img src="https://s3.ap-south-1.amazonaws.com/beardoc/images/ios-closebutton.png" /></div>
		<img src="https://s3.ap-south-1.amazonaws.com/beardoc/images/ios-addtohomescreen-black.png" />
	</div>
</div>
<script>
const isIos = () => {
  const userAgent = window.navigator.userAgent.toLowerCase();
  return /iphone/.test( userAgent );
}
// Detects if device is in standalone mode
const isInStandaloneMode = () => ('standalone' in window.navigator) && (window.navigator.standalone);

// Checks if should display install popup notification:
if (isIos() && !isInStandaloneMode()) {
	let showiosprompt = localStorage.getItem("showiosprompt");
	if(showiosprompt == null || showiosprompt == undefined)
	{
		showiosprompt = "Y";
	}
	if(showiosprompt == "Y"){
		setTimeout(() => {
			document.querySelector('.ios-addtohome').classList.add('show');
		}, 5000);
	}
	document.querySelector('.ios-addtohome-close').addEventListener('click', (e) => {
		document.querySelector('.ios-addtohome').classList.remove('show');
		localStorage.setItem("showiosprompt", "N");
	});
}
</script>

	</body>
</html>